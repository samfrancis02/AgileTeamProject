﻿namespace Agile_Project_Atm_machine
{
    partial class balanceViewcs
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            accountNameLabel = new Label();
            balanceLabel = new Label();
            label3 = new Label();
            SuspendLayout();
            // 
            // accountNameLabel
            // 
            accountNameLabel.Anchor = AnchorStyles.None;
            accountNameLabel.AutoSize = true;
            accountNameLabel.BackColor = Color.ForestGreen;
            accountNameLabel.Font = new Font("Segoe UI", 14F, FontStyle.Bold, GraphicsUnit.Point, 0);
            accountNameLabel.ForeColor = Color.White;
            accountNameLabel.Location = new Point(61, 68);
            accountNameLabel.Margin = new Padding(2, 0, 2, 0);
            accountNameLabel.Name = "accountNameLabel";
            accountNameLabel.Size = new Size(375, 32);
            accountNameLabel.TabIndex = 9;
            accountNameLabel.Text = "Account name: {account_name}";
            // 
            // balanceLabel
            // 
            balanceLabel.Anchor = AnchorStyles.None;
            balanceLabel.AutoSize = true;
            balanceLabel.BackColor = Color.ForestGreen;
            balanceLabel.Font = new Font("Segoe UI", 14F, FontStyle.Bold, GraphicsUnit.Point, 0);
            balanceLabel.ForeColor = Color.White;
            balanceLabel.Location = new Point(61, 152);
            balanceLabel.Margin = new Padding(2, 0, 2, 0);
            balanceLabel.Name = "balanceLabel";
            balanceLabel.Size = new Size(324, 32);
            balanceLabel.TabIndex = 10;
            balanceLabel.Text = "Account balance: {balance}";
            // 
            // label3
            // 
            label3.Anchor = AnchorStyles.None;
            label3.AutoSize = true;
            label3.BackColor = Color.ForestGreen;
            label3.Font = new Font("Segoe UI", 14F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.ForeColor = Color.White;
            label3.Location = new Point(231, 304);
            label3.Margin = new Padding(2, 0, 2, 0);
            label3.Name = "label3";
            label3.Size = new Size(324, 32);
            label3.TabIndex = 11;
            label3.Text = "Click anywhere to continue";
            // 
            // balanceViewcs
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.ForestGreen;
            ClientSize = new Size(800, 450);
            Controls.Add(label3);
            Controls.Add(balanceLabel);
            Controls.Add(accountNameLabel);
            Name = "balanceViewcs";
            Text = "balanceViewcs";
            WindowState = FormWindowState.Maximized;
            Load += balanceViewcs_Load;
            Click += balanceViewcs_Click;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label accountNameLabel;
        private Label balanceLabel;
        private Label label3;
    }
}