﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Agile_Project_Atm_machine
{
    public partial class balanceViewcs : Form
    {
        public balanceViewcs()
        {
            InitializeComponent();
        }

        private void balanceViewcs_Click(object sender, EventArgs e)
        {
            askAnyOtherAction askAnyOtherAction = new askAnyOtherAction();
            askAnyOtherAction.Show();
            this.Close();
        }

        private void balanceViewcs_Load(object sender, EventArgs e)
        {

        }
    }
}
